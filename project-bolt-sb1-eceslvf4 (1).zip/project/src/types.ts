export interface UserRegistration {
  name: string;
  email: string;
  password: string;
}

export interface Organization {
  name: string;
  website: string;
  description: string;
}

export interface WebpageStatus {
  url: string;
  status: 'pending' | 'scraped' | 'failed';
  chunks?: string[];
}

export interface Step {
  id: number;
  title: string;
  description: string;
}