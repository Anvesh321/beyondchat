import React, { useState } from 'react';
import { CheckCircle2, Clock, XCircle, ChevronDown, ChevronUp } from 'lucide-react';
import type { WebpageStatus } from '../types';

const DUMMY_DATA: WebpageStatus[] = [
  {
    url: '/about',
    status: 'scraped',
    chunks: [
      'BeyondChats is a leading AI chatbot platform',
      'Founded in 2023, we help businesses automate customer support',
      'Our mission is to make AI accessible to everyone',
    ],
  },
  {
    url: '/pricing',
    status: 'scraped',
    chunks: [
      'Flexible pricing plans starting at $29/month',
      'Enterprise solutions available for large organizations',
    ],
  },
  {
    url: '/features',
    status: 'pending',
  },
  {
    url: '/contact',
    status: 'failed',
  },
];

export function WebsiteScraping() {
  const [expandedUrl, setExpandedUrl] = useState<string | null>(null);

  const getStatusIcon = (status: WebpageStatus['status']) => {
    switch (status) {
      case 'scraped':
        return <CheckCircle2 className="h-5 w-5 text-green-500" />;
      case 'pending':
        return <Clock className="h-5 w-5 text-yellow-500" />;
      case 'failed':
        return <XCircle className="h-5 w-5 text-red-500" />;
    }
  };

  return (
    <div className="w-full max-w-3xl">
      <div className="bg-white shadow rounded-lg">
        <div className="px-4 py-5 sm:p-6">
          <h3 className="text-lg font-medium leading-6 text-gray-900">Website Scraping Progress</h3>
          <div className="mt-4 space-y-4">
            {DUMMY_DATA.map((page) => (
              <div key={page.url} className="border rounded-lg">
                <button
                  onClick={() => setExpandedUrl(expandedUrl === page.url ? null : page.url)}
                  className="w-full px-4 py-3 flex items-center justify-between hover:bg-gray-50"
                >
                  <div className="flex items-center space-x-3">
                    {getStatusIcon(page.status)}
                    <span className="text-sm font-medium text-gray-900">{page.url}</span>
                  </div>
                  {page.chunks && (
                    expandedUrl === page.url ? (
                      <ChevronUp className="h-5 w-5 text-gray-400" />
                    ) : (
                      <ChevronDown className="h-5 w-5 text-gray-400" />
                    )
                  )}
                </button>
                {expandedUrl === page.url && page.chunks && (
                  <div className="px-4 pb-3 space-y-2">
                    {page.chunks.map((chunk, index) => (
                      <div
                        key={index}
                        className="p-2 bg-gray-50 rounded text-sm text-gray-600"
                      >
                        {chunk}
                      </div>
                    ))}
                  </div>
                )}
              </div>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
}