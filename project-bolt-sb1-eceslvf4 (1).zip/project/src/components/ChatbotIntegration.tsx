import React, { useState } from 'react';
import { Code, Mail, ExternalLink, Share2 } from 'lucide-react';

const INTEGRATION_CODE = `<script>
  window.beyondChatsConfig = {
    apiKey: 'YOUR_API_KEY',
    organizationId: 'YOUR_ORG_ID'
  };
</script>
<script src="https://cdn.beyondchats.com/widget.js"></script>`;

export function ChatbotIntegration() {
  const [integrationDetected, setIntegrationDetected] = useState(false);
  const [showSuccess, setShowSuccess] = useState(false);

  const handleTestIntegration = () => {
    // Simulate integration check
    setTimeout(() => {
      setIntegrationDetected(true);
      setShowSuccess(true);
    }, 1500);
  };

  return (
    <div className="w-full max-w-3xl">
      <div className="space-y-6">
        <div className="bg-white shadow rounded-lg divide-y divide-gray-200">
          <div className="px-4 py-5 sm:p-6">
            <h3 className="text-lg font-medium leading-6 text-gray-900">
              Test Your Chatbot
            </h3>
            <div className="mt-2 max-w-xl text-sm text-gray-500">
              <p>Preview how your chatbot will appear on your website.</p>
            </div>
            <div className="mt-5">
              <button
                type="button"
                className="inline-flex items-center px-4 py-2 border border-transparent text-sm font-medium rounded-md shadow-sm text-white bg-blue-600 hover:bg-blue-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-blue-500"
                onClick={() => window.open('#', '_blank')}
              >
                <ExternalLink className="mr-2 h-4 w-4" />
                Open Preview
              </button>
            </div>
          </div>

          <div className="px-4 py-5 sm:p-6">
            <h3 className="text-lg font-medium leading-6 text-gray-900">
              Integration Options
            </h3>
            <div className="mt-5 space-y-4">
              <div className="rounded-md bg-gray-50 p-4">
                <div className="flex">
                  <div className="flex-shrink-0">
                    <Code className="h-5 w-5 text-gray-400" />
                  </div>
                  <div className="ml-3">
                    <h3 className="text-sm font-medium text-gray-900">
                      Add to Your Website
                    </h3>
                    <div className="mt-2">
                      <pre className="p-3 bg-gray-800 text-white rounded-md overflow-x-auto">
                        <code>{INTEGRATION_CODE}</code>
                      </pre>
                    </div>
                  </div>
                </div>
              </div>

              <div className="rounded-md bg-gray-50 p-4">
                <div className="flex">
                  <div className="flex-shrink-0">
                    <Mail className="h-5 w-5 text-gray-400" />
                  </div>
                  <div className="ml-3">
                    <h3 className="text-sm font-medium text-gray-900">
                      Email Instructions to Developer
                    </h3>
                    <div className="mt-2">
                      <button
                        type="button"
                        className="inline-flex items-center px-3 py-2 border border-gray-300 shadow-sm text-sm leading-4 font-medium rounded-md text-gray-700 bg-white hover:bg-gray-50 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-blue-500"
                        onClick={() => window.location.href = 'mailto:?subject=BeyondChats Integration Instructions'}
                      >
                        Send Email
                      </button>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>

          <div className="px-4 py-5 sm:p-6">
            <h3 className="text-lg font-medium leading-6 text-gray-900">
              Verify Integration
            </h3>
            <div className="mt-5">
              <button
                type="button"
                className="inline-flex items-center px-4 py-2 border border-transparent text-sm font-medium rounded-md shadow-sm text-white bg-blue-600 hover:bg-blue-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-blue-500"
                onClick={handleTestIntegration}
              >
                Test Integration
              </button>
            </div>
          </div>
        </div>

        {showSuccess && (
          <div className="fixed inset-0 bg-gray-500 bg-opacity-75 flex items-center justify-center">
            <div className="bg-white rounded-lg p-8 max-w-md w-full">
              <div className="text-center">
                <h3 className="text-lg font-medium text-gray-900 mb-4">
                  {integrationDetected ? 'Integration Successful! 🎉' : 'Integration Not Detected'}
                </h3>
                {integrationDetected ? (
                  <div className="space-y-4">
                    <button
                      type="button"
                      className="w-full inline-flex justify-center items-center px-4 py-2 border border-transparent text-sm font-medium rounded-md shadow-sm text-white bg-blue-600 hover:bg-blue-700"
                    >
                      Explore Admin Panel
                    </button>
                    <button
                      type="button"
                      className="w-full inline-flex justify-center items-center px-4 py-2 border border-gray-300 text-sm font-medium rounded-md shadow-sm text-gray-700 bg-white hover:bg-gray-50"
                    >
                      Start Talking to Your Chatbot
                    </button>
                    <div className="flex justify-center space-x-4">
                      <button
                        type="button"
                        className="inline-flex items-center px-3 py-2 border border-gray-300 shadow-sm text-sm leading-4 font-medium rounded-md text-gray-700 bg-white hover:bg-gray-50"
                      >
                        <Share2 className="h-4 w-4 mr-2" />
                        Share
                      </button>
                    </div>
                  </div>
                ) : (
                  <p className="text-sm text-gray-500">
                    We couldn't detect the chatbot on your website. Please verify the integration code is properly installed.
                  </p>
                )}
              </div>
            </div>
          </div>
        )}
      </div>
    </div>
  );
}