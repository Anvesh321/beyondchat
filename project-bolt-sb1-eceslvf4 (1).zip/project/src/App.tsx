import React, { useState } from 'react';
import { Bot, Building2, Code } from 'lucide-react';
import { AuthForm } from './components/AuthForm';
import { OrganizationSetup } from './components/OrganizationSetup';
import { WebsiteScraping } from './components/WebsiteScraping';
import { ChatbotIntegration } from './components/ChatbotIntegration';
import type { Step } from './types';

const steps: Step[] = [
  {
    id: 1,
    title: 'Create Account',
    description: 'Set up your BeyondChats account',
  },
  {
    id: 2,
    title: 'Organization Setup',
    description: 'Tell us about your business',
  },
  {
    id: 3,
    title: 'Website Analysis',
    description: 'We\'ll analyze your website content',
  },
  {
    id: 4,
    title: 'Integration',
    description: 'Add the chatbot to your site',
  },
];

function App() {
  const [currentStep, setCurrentStep] = useState(1);

  const getStepIcon = (step: Step) => {
    switch (step.id) {
      case 1:
        return <Bot className="h-6 w-6" />;
      case 2:
        return <Building2 className="h-6 w-6" />;
      case 3:
        return <Bot className="h-6 w-6" />;
      case 4:
        return <Code className="h-6 w-6" />;
    }
  };

  return (
    <div className="min-h-screen bg-pattern">
      <div className="py-12">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-12 animate-slide-down">
            <div className="inline-block p-2 px-4 rounded-full bg-blue-50 text-blue-700 mb-4 animate-fade-in">
              Welcome to the future of customer support
            </div>
            <h1 className="text-4xl font-bold text-gray-900 mb-2">Welcome to BeyondChats</h1>
            <p className="mt-2 text-lg text-gray-600">Let's get your AI chatbot up and running</p>
          </div>

          <nav aria-label="Progress" className="mb-12 animate-fade-in" style={{ animationDelay: '0.2s' }}>
            <ol className="flex items-center justify-center">
              {steps.map((step, stepIdx) => (
                <li
                  key={step.id}
                  className={`${
                    stepIdx !== steps.length - 1 ? 'pr-8 sm:pr-20' : ''
                  } relative progress-step`}
                >
                  <div className="flex items-center">
                    <div
                      className={`${
                        step.id <= currentStep
                          ? 'bg-blue-600 text-white'
                          : 'bg-gray-200 text-gray-500'
                      } h-14 w-14 rounded-full flex items-center justify-center transition-colors duration-500 shadow-lg`}
                    >
                      {getStepIcon(step)}
                    </div>
                    {stepIdx !== steps.length - 1 && (
                      <div
                        className={`hidden sm:block absolute top-7 left-16 h-0.5 w-32 transition-colors duration-500 ${
                          step.id < currentStep ? 'bg-blue-600' : 'bg-gray-200'
                        }`}
                      />
                    )}
                  </div>
                  <div className="mt-3">
                    <span className="text-sm font-semibold text-blue-600">
                      {step.title}
                    </span>
                    <p className="text-sm text-gray-500">{step.description}</p>
                  </div>
                </li>
              ))}
            </ol>
          </nav>

          <div className="flex justify-center animate-scale-in" style={{ animationDelay: '0.4s' }}>
            <div className="w-full glass-effect rounded-2xl p-8 form-container">
              {currentStep === 1 && (
                <AuthForm onSubmit={() => setCurrentStep(2)} />
              )}
              {currentStep === 2 && (
                <OrganizationSetup onSubmit={() => setCurrentStep(3)} />
              )}
              {currentStep === 3 && (
                <div className="space-y-6">
                  <WebsiteScraping />
                  <div className="flex justify-center">
                    <button
                      onClick={() => setCurrentStep(4)}
                      className="inline-flex items-center px-6 py-3 border border-transparent text-base font-medium rounded-full shadow-lg text-white bg-blue-600 hover:bg-blue-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-blue-500 transition-all duration-300 hover:transform hover:scale-105"
                    >
                      Continue to Integration
                    </button>
                  </div>
                </div>
              )}
              {currentStep === 4 && <ChatbotIntegration />}
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}

export default App;