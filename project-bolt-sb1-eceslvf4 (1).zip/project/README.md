# BeyondChats - AI Chatbot Integration Platform

BeyondChats is a modern, user-friendly platform that helps businesses integrate AI-powered chatbots into their websites. This application provides a streamlined setup process for creating and deploying custom chatbots trained on your website's content.

![BeyondChats Screenshot](https://images.unsplash.com/photo-1531746790731-6c087fecd65a?auto=format&fit=crop&q=80&w=1600)

## Features

### 1. User Registration & Authentication
- Email and password registration
- Google OAuth integration
- Email verification system
- Secure authentication flow

### 2. Organization Setup
- Company profile creation
- Website URL integration
- Company description management
- Automated meta-description fetching

### 3. Website Content Analysis
- Automated webpage detection
- Content scraping and analysis
- Real-time progress tracking
- Detailed content chunk visualization

### 4. Chatbot Integration
- One-click chatbot testing
- Simple integration code
- Developer instructions
- Integration verification system
- Success tracking and notifications

## Tech Stack

- **Frontend**: React 18
- **Styling**: Tailwind CSS
- **Icons**: Lucide React
- **Type Safety**: TypeScript
- **Build Tool**: Vite
- **Deployment**: Netlify

## Getting Started

1. Clone the repository
2. Install dependencies:
   ```bash
   npm install
   ```
3. Start the development server:
   ```bash
   npm run dev
   ```

## Project Structure

```
src/
├── components/         # React components
│   ├── AuthForm.tsx
│   ├── OrganizationSetup.tsx
│   ├── WebsiteScraping.tsx
│   └── ChatbotIntegration.tsx
├── types.ts           # TypeScript interfaces
├── App.tsx           # Main application component
└── main.tsx         # Application entry point
```

## Development

### Prerequisites
- Node.js 16+
- npm or yarn

### Available Scripts

- `npm run dev` - Start development server
- `npm run build` - Build for production
- `npm run preview` - Preview production build
- `npm run lint` - Run ESLint

## Deployment

The application is deployed on Netlify. You can view the live version at:
[https://deluxe-pithivier-9639e7.netlify.app](https://deluxe-pithivier-9639e7.netlify.app)

## UI/UX Features

- Beautiful gradient patterns
- Glass morphism effects
- Smooth animations
- Responsive design
- Interactive progress indicators
- Modern form elements

## Contributing

1. Fork the repository
2. Create your feature branch (`git checkout -b feature/AmazingFeature`)
3. Commit your changes (`git commit -m 'Add some AmazingFeature'`)
4. Push to the branch (`git push origin feature/AmazingFeature`)
5. Open a Pull Request

## License

This project is licensed under the MIT License - see the LICENSE file for details.

## Support

For support, email support@beyondchats.com or join our Slack channel.

## Acknowledgments

- React team for the amazing framework
- Tailwind CSS for the utility-first CSS framework
- Lucide for the beautiful icons
- All contributors who have helped shape BeyondChats